CREATE TABLE IF NOT EXISTS contacts (
  id uuid PRIMARY KEY,
  display_name text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  created_by_user_id uuid NOT NULL REFERENCES user_profiles(id),
  created_at timestamptz NOT NULL,
  version integer NOT NULL DEFAULT 1,
  CONSTRAINT contacts_status_check CHECK (status IN ('active')),
  CONSTRAINT contacts_version_check CHECK (version >= 1)
);

CREATE INDEX IF NOT EXISTS contacts_created_by_user_id_idx ON contacts (created_by_user_id);
CREATE INDEX IF NOT EXISTS contacts_created_at_idx ON contacts (created_at);

CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id uuid NOT NULL REFERENCES user_profiles(id),
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  before_data jsonb,
  after_data jsonb,
  correlation_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS audit_logs_entity_idx ON audit_logs (entity_type, entity_id);
CREATE INDEX IF NOT EXISTS audit_logs_actor_created_at_idx ON audit_logs (actor_user_id, created_at);

CREATE TABLE IF NOT EXISTS transactional_outbox (
  event_id uuid PRIMARY KEY,
  aggregate_type text NOT NULL,
  aggregate_id uuid NOT NULL,
  event_name text NOT NULL,
  event_version integer NOT NULL,
  payload jsonb NOT NULL,
  metadata jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  attempts integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  next_attempt_at timestamptz,
  processed_at timestamptz,
  last_error text,
  CONSTRAINT transactional_outbox_status_check CHECK (status IN ('pending')),
  CONSTRAINT transactional_outbox_attempts_check CHECK (attempts >= 0)
);

CREATE INDEX IF NOT EXISTS transactional_outbox_status_created_at_idx
  ON transactional_outbox (status, created_at);

CREATE INDEX IF NOT EXISTS transactional_outbox_aggregate_idx
  ON transactional_outbox (aggregate_type, aggregate_id);
