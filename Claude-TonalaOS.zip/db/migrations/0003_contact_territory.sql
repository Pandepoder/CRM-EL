CREATE TABLE IF NOT EXISTS contact_territory (
  contact_id uuid PRIMARY KEY REFERENCES contacts(id),
  colony_id uuid NOT NULL REFERENCES colonies(id),
  territory_status text NOT NULL,
  linked_by_user_id uuid NOT NULL REFERENCES user_profiles(id),
  linked_at timestamptz NOT NULL,
  version integer NOT NULL DEFAULT 1,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT contact_territory_status_check CHECK (territory_status IN ('confirmed')),
  CONSTRAINT contact_territory_version_check CHECK (version >= 1)
);

CREATE INDEX IF NOT EXISTS contact_territory_colony_id_idx
  ON contact_territory (colony_id);

CREATE INDEX IF NOT EXISTS contact_territory_linked_by_user_id_idx
  ON contact_territory (linked_by_user_id);
