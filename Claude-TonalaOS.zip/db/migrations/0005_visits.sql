CREATE TABLE IF NOT EXISTS visits (
  id uuid PRIMARY KEY,
  contact_id uuid NOT NULL REFERENCES contacts(id),
  colony_id uuid NOT NULL REFERENCES colonies(id),
  assigned_user_id uuid NOT NULL REFERENCES user_profiles(id),
  scheduled_at timestamptz NOT NULL,
  status text NOT NULL,
  visit_location_text text NOT NULL,
  created_by_user_id uuid NOT NULL REFERENCES user_profiles(id),
  created_at timestamptz NOT NULL,
  completed_at timestamptz,
  completed_by_user_id uuid REFERENCES user_profiles(id),
  version integer NOT NULL DEFAULT 1,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT visits_status_check CHECK (status IN ('scheduled', 'completed')),
  CONSTRAINT visits_version_check CHECK (version >= 1),
  CONSTRAINT visits_location_text_check CHECK (length(trim(visit_location_text)) > 0),
  CONSTRAINT visits_completion_state_check CHECK (
    (status = 'scheduled' AND completed_at IS NULL AND completed_by_user_id IS NULL)
    OR
    (status = 'completed' AND completed_at IS NOT NULL AND completed_by_user_id IS NOT NULL)
  )
);

CREATE INDEX IF NOT EXISTS visits_assigned_user_id_idx ON visits (assigned_user_id);
CREATE INDEX IF NOT EXISTS visits_scheduled_at_idx ON visits (scheduled_at);
CREATE INDEX IF NOT EXISTS visits_status_idx ON visits (status);

CREATE TABLE IF NOT EXISTS visit_results (
  visit_id uuid PRIMARY KEY REFERENCES visits(id),
  structured_outcome text NOT NULL,
  summary text NOT NULL,
  completed_by_user_id uuid NOT NULL REFERENCES user_profiles(id),
  completed_at timestamptz NOT NULL,
  CONSTRAINT visit_results_outcome_check CHECK (
    structured_outcome IN ('successful', 'no_contact', 'follow_up_required', 'rejected')
  ),
  CONSTRAINT visit_results_summary_check CHECK (length(trim(summary)) > 0)
);
