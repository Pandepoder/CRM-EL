CREATE TABLE IF NOT EXISTS projection_states (
  projection_name text NOT NULL,
  projection_version text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  last_processed_event_id text,
  last_processed_event_created_at timestamptz,
  last_processed_at timestamptz,
  rebuild_started_at timestamptz,
  rebuild_completed_at timestamptz,
  failure_count integer NOT NULL DEFAULT 0,
  last_error text,
  version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (projection_name, projection_version),
  CONSTRAINT projection_states_name_check CHECK (length(trim(projection_name)) > 0),
  CONSTRAINT projection_states_version_text_check CHECK (length(trim(projection_version)) > 0),
  CONSTRAINT projection_states_status_check CHECK (status IN ('active', 'rebuilding', 'paused', 'failed', 'deprecated')),
  CONSTRAINT projection_states_failure_count_check CHECK (failure_count >= 0),
  CONSTRAINT projection_states_version_check CHECK (version >= 1),
  CONSTRAINT projection_states_checkpoint_pair_check CHECK (
    (last_processed_event_id IS NULL AND last_processed_event_created_at IS NULL)
    OR
    (last_processed_event_id IS NOT NULL AND last_processed_event_created_at IS NOT NULL)
  )
);

CREATE INDEX IF NOT EXISTS projection_states_status_idx
  ON projection_states (status);

CREATE TABLE IF NOT EXISTS projection_event_receipts (
  projection_name text NOT NULL,
  projection_version text NOT NULL,
  event_id text NOT NULL,
  event_name text NOT NULL,
  event_version text NOT NULL,
  event_created_at timestamptz NOT NULL,
  processed_at timestamptz NOT NULL,
  PRIMARY KEY (projection_name, projection_version, event_id),
  CONSTRAINT projection_event_receipts_name_check CHECK (length(trim(projection_name)) > 0),
  CONSTRAINT projection_event_receipts_version_check CHECK (length(trim(projection_version)) > 0),
  CONSTRAINT projection_event_receipts_event_id_check CHECK (length(trim(event_id)) > 0),
  CONSTRAINT projection_event_receipts_event_name_check CHECK (length(trim(event_name)) > 0),
  CONSTRAINT projection_event_receipts_event_version_check CHECK (length(trim(event_version)) > 0)
);

CREATE INDEX IF NOT EXISTS projection_event_receipts_projection_idx
  ON projection_event_receipts (projection_name, projection_version);

CREATE INDEX IF NOT EXISTS projection_event_receipts_event_created_at_idx
  ON projection_event_receipts (event_created_at);

CREATE TABLE IF NOT EXISTS projection_rebuild_receipts (
  rebuild_id text NOT NULL,
  projection_name text NOT NULL,
  projection_version text NOT NULL,
  event_id text NOT NULL,
  event_name text NOT NULL,
  event_version text NOT NULL,
  event_created_at timestamptz NOT NULL,
  processed_at timestamptz NOT NULL,
  PRIMARY KEY (rebuild_id, projection_name, projection_version, event_id),
  CONSTRAINT projection_rebuild_receipts_rebuild_id_check CHECK (length(trim(rebuild_id)) > 0),
  CONSTRAINT projection_rebuild_receipts_name_check CHECK (length(trim(projection_name)) > 0),
  CONSTRAINT projection_rebuild_receipts_version_check CHECK (length(trim(projection_version)) > 0),
  CONSTRAINT projection_rebuild_receipts_event_id_check CHECK (length(trim(event_id)) > 0),
  CONSTRAINT projection_rebuild_receipts_event_name_check CHECK (length(trim(event_name)) > 0),
  CONSTRAINT projection_rebuild_receipts_event_version_check CHECK (length(trim(event_version)) > 0)
);

CREATE INDEX IF NOT EXISTS projection_rebuild_receipts_rebuild_idx
  ON projection_rebuild_receipts (rebuild_id);

CREATE INDEX IF NOT EXISTS projection_rebuild_receipts_projection_idx
  ON projection_rebuild_receipts (projection_name, projection_version);

CREATE INDEX IF NOT EXISTS projection_rebuild_receipts_event_created_at_idx
  ON projection_rebuild_receipts (event_created_at);
