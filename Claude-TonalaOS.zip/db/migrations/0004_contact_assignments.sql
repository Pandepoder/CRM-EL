CREATE TABLE IF NOT EXISTS contact_assignments (
  contact_id uuid PRIMARY KEY REFERENCES contacts(id),
  assigned_user_id uuid NOT NULL REFERENCES user_profiles(id),
  assignment_status text NOT NULL,
  assigned_by_user_id uuid NOT NULL REFERENCES user_profiles(id),
  assigned_at timestamptz NOT NULL,
  version integer NOT NULL DEFAULT 1,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT contact_assignments_status_check CHECK (assignment_status IN ('active')),
  CONSTRAINT contact_assignments_version_check CHECK (version >= 1)
);

CREATE INDEX IF NOT EXISTS contact_assignments_assigned_user_id_idx
  ON contact_assignments (assigned_user_id);

CREATE INDEX IF NOT EXISTS contact_assignments_status_idx
  ON contact_assignments (assignment_status);
