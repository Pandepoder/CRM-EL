ALTER TABLE transactional_outbox
  ADD COLUMN IF NOT EXISTS locked_at timestamptz,
  ADD COLUMN IF NOT EXISTS locked_by text;

ALTER TABLE transactional_outbox
  DROP CONSTRAINT IF EXISTS transactional_outbox_status_check;

ALTER TABLE transactional_outbox
  ADD CONSTRAINT transactional_outbox_status_check
  CHECK (status IN ('pending', 'processing', 'processed', 'dead_letter'));

CREATE INDEX IF NOT EXISTS transactional_outbox_claim_idx
  ON transactional_outbox (status, next_attempt_at, created_at, event_id);

CREATE INDEX IF NOT EXISTS transactional_outbox_locked_at_idx
  ON transactional_outbox (status, locked_at);

CREATE TABLE IF NOT EXISTS outbox_consumer_receipts (
  event_id uuid NOT NULL REFERENCES transactional_outbox(event_id),
  consumer_name text NOT NULL,
  processed_at timestamptz NOT NULL,
  result_metadata jsonb,
  CONSTRAINT outbox_consumer_receipts_consumer_name_check CHECK (length(trim(consumer_name)) > 0),
  PRIMARY KEY (event_id, consumer_name)
);

CREATE TABLE IF NOT EXISTS processed_event_log (
  event_id uuid NOT NULL REFERENCES transactional_outbox(event_id),
  consumer_name text NOT NULL,
  event_name text NOT NULL,
  aggregate_type text NOT NULL,
  aggregate_id uuid NOT NULL,
  processed_at timestamptz NOT NULL,
  CONSTRAINT processed_event_log_consumer_name_check CHECK (length(trim(consumer_name)) > 0),
  PRIMARY KEY (event_id, consumer_name)
);
