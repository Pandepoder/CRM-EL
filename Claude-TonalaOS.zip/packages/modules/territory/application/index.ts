export { getContactTerritory, type GetContactTerritoryInput } from "./get-contact-territory.js";
export { linkContactToColony, type LinkContactToColonyInput } from "./link-contact-to-colony.js";
export type {
  AuditWriter,
  ContactTerritoryRepository,
  GetContactTerritoryDependencies,
  IdGenerator,
  LinkContactToColonyDependencies,
  OutboxWriter,
  TerritoryCatalogReader,
  TransactionContext,
  TransactionManager,
  UseCaseResult
} from "./ports.js";
