export const routesDomainName = "routes";
