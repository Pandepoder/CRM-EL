export const commandCenterApplicationName = "command-center-application";
