import { DomainError } from "@tonala/shared/errors";
import { type EntityId } from "@tonala/shared/kernel";

export const AssignmentStatus = {
  Active: "active"
} as const;

export type AssignmentStatus = (typeof AssignmentStatus)[keyof typeof AssignmentStatus];

export type ContactAssignment = Readonly<{
  contactId: EntityId;
  assignedUserId: EntityId;
  assignmentStatus: AssignmentStatus;
  assignedByUserId: EntityId;
  assignedAt: Date;
  version: number;
}>;

export function createInitialContactAssignment(input: {
  readonly contactId: EntityId;
  readonly assignedUserId: EntityId;
  readonly assignedByUserId: EntityId;
  readonly assignedAt: Date;
}): ContactAssignment {
  return {
    contactId: input.contactId,
    assignedUserId: input.assignedUserId,
    assignmentStatus: AssignmentStatus.Active,
    assignedByUserId: input.assignedByUserId,
    assignedAt: input.assignedAt,
    version: 1
  };
}

export function reassignContact(
  current: ContactAssignment,
  input: {
    readonly assignedUserId: EntityId;
    readonly assignedByUserId: EntityId;
    readonly assignedAt: Date;
  }
): ContactAssignment {
  if (current.version < 1) {
    throw new DomainError({
      code: "invalid_contact_assignment_version",
      message: "Contact assignment version must be greater than or equal to 1.",
      publicMessage: "Assignment state is invalid."
    });
  }

  return {
    contactId: current.contactId,
    assignedUserId: input.assignedUserId,
    assignmentStatus: AssignmentStatus.Active,
    assignedByUserId: input.assignedByUserId,
    assignedAt: input.assignedAt,
    version: current.version + 1
  };
}
