export const governanceApplicationName = "governance-application";
