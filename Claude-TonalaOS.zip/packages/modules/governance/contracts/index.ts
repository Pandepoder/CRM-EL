export const governanceContractsName = "governance-contracts";
