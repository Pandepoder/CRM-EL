export const governanceInfrastructureName = "governance-infrastructure";
