export { getContactById, type GetContactByIdInput } from "./get-contact-by-id.js";
export {
  registerMinimalContact,
  type RegisterMinimalContactInput
} from "./register-minimal-contact.js";
export type {
  AuditWriter,
  ContactRepository,
  GetContactByIdDependencies,
  IdGenerator,
  OutboxWriter,
  RegisterMinimalContactDependencies,
  TransactionContext,
  TransactionManager,
  UseCaseResult
} from "./ports.js";
