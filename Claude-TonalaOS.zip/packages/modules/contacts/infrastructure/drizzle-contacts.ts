import { sql, type SQL } from "drizzle-orm";
import { type Database } from "@tonala/shared/database";
import { createEntityId } from "@tonala/shared/kernel";

import { type ContactsReader, type ContactRegisteredV1 } from "../contracts/index.js";
import {
  type AuditWriter,
  type ContactRepository,
  type IdGenerator,
  type OutboxWriter,
  type TransactionContext,
  type TransactionManager
} from "../application/index.js";
import { type Contact } from "../domain/index.js";

type QueryResult<TRow> = {
  readonly rows: TRow[];
};

type DrizzleExecutor = {
  execute<TRow extends Record<string, unknown>>(query: SQL): Promise<QueryResult<TRow>>;
};

type DrizzleTransactionContext = TransactionContext & Readonly<{ client: DrizzleExecutor }>;

function executorFrom(tx: TransactionContext): DrizzleExecutor {
  const candidate = tx as Partial<DrizzleTransactionContext>;
  if (!candidate.client) {
    throw new Error("Transaction context does not contain a Drizzle executor");
  }
  return candidate.client;
}

export class CryptoIdGenerator implements IdGenerator {
  public newId() {
    return createEntityId(crypto.randomUUID());
  }
}

export class DrizzleTransactionManager implements TransactionManager {
  public constructor(private readonly db: Database) {}

  public async transaction<T>(run: (tx: TransactionContext) => Promise<T>): Promise<T> {
    return this.db.transaction(async (client) => {
      const tx: DrizzleTransactionContext = {
        id: crypto.randomUUID(),
        client: client as DrizzleExecutor
      };
      return run(tx);
    });
  }
}

export class DrizzleContactRepository implements ContactRepository {
  public constructor(private readonly db: Database) {}

  public async insert(contact: Contact, tx: TransactionContext): Promise<void> {
    await executorFrom(tx).execute(sql`
      INSERT INTO contacts (id, display_name, status, created_by_user_id, created_at, version)
      VALUES (
        ${contact.contactId},
        ${contact.displayName},
        ${contact.status},
        ${contact.createdByUserId},
        ${contact.createdAt.toISOString()},
        ${contact.version}
      )
    `);
  }

  public async findById(contactId: ReturnType<typeof createEntityId>) {
    const result = await this.db.execute<{
      contact_id: string;
      display_name: string;
      status: "active";
      created_at: Date;
      version: number;
    }>(sql`
      SELECT
        id::text AS contact_id,
        display_name,
        status,
        created_at,
        version
      FROM contacts
      WHERE id = ${contactId}
      LIMIT 1
    `);
    const row = result.rows[0];
    return row
      ? {
      contactId: createEntityId(row.contact_id),
      displayName: row.display_name,
      status: row.status,
      createdAt: new Date(row.created_at).toISOString(),
      version: row.version
    }
      : null;
  }
}

export class DrizzleContactsReader implements ContactsReader {
  public constructor(private readonly db: Database) {}

  public async getContactStatus(contactId: ReturnType<typeof createEntityId>) {
    const result = await this.db.execute<{
      contact_id: string;
      status: "active";
      version: number;
    }>(sql`
      SELECT id::text AS contact_id, status, version
      FROM contacts
      WHERE id = ${contactId}
      LIMIT 1
    `);
    const row = result.rows[0];
    return row
      ? {
      contactId: createEntityId(row.contact_id),
      status: row.status,
      version: row.version
    }
      : null;
  }
}

export class DrizzleAuditWriter implements AuditWriter {
  public async write(input: Parameters<AuditWriter["write"]>[0], tx: TransactionContext): Promise<void> {
    await executorFrom(tx).execute(sql`
      INSERT INTO audit_logs (
        actor_user_id,
        action,
        entity_type,
        entity_id,
        before_data,
        after_data,
        correlation_id
      )
      VALUES (
        ${input.actor.actorId},
        ${input.action},
        ${input.entityType},
        ${input.entityId},
        ${JSON.stringify(input.beforeData)}::jsonb,
        ${JSON.stringify(input.afterData)}::jsonb,
        ${input.actor.correlationId}
      )
    `);
  }
}

export class DrizzleOutboxWriter implements OutboxWriter {
  public async writeContactRegistered(
    input: Parameters<OutboxWriter["writeContactRegistered"]>[0],
    tx: TransactionContext
  ): Promise<void> {
    const event: ContactRegisteredV1 = {
      name: "ContactRegistered.v1",
      version: 1,
      payload: {
        contact_id: input.contact.contactId,
        created_by_user_id: input.contact.createdByUserId,
        created_at: input.contact.createdAt.toISOString()
      },
      metadata: {
        event_id: input.eventId,
        event_name: "ContactRegistered.v1",
        event_version: 1,
        occurred_at: input.occurredAt.toISOString(),
        correlation_id: input.actor.correlationId,
        actor_id: input.actor.actorId,
        aggregate_type: "contact",
        aggregate_id: input.contact.contactId
      }
    };

    await executorFrom(tx).execute(sql`
      INSERT INTO transactional_outbox (
        event_id,
        aggregate_type,
        aggregate_id,
        event_name,
        event_version,
        payload,
        metadata,
        status,
        attempts
      )
      VALUES (
        ${input.eventId},
        'contact',
        ${input.contact.contactId},
        'ContactRegistered.v1',
        1,
        ${JSON.stringify(event.payload)}::jsonb,
        ${JSON.stringify(event.metadata)}::jsonb,
        'pending',
        0
      )
    `);
  }
}
