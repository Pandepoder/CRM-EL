import { type CorrelationId, type EntityId } from "@tonala/shared/kernel";

export type ContactId = EntityId;

export type ContactSummary = Readonly<{
  contactId: ContactId;
  displayName: string;
  status: "active";
  createdAt: string;
  version: number;
}>;

export type ContactStatusView = Readonly<{
  contactId: ContactId;
  status: "active";
  version: number;
}>;

export interface ContactsReader {
  getContactStatus(contactId: ContactId): Promise<ContactStatusView | null>;
}

export type ContactRegisteredV1Payload = Readonly<{
  contact_id: string;
  created_by_user_id: string;
  created_at: string;
}>;

export type ContactRegisteredV1Metadata = Readonly<{
  event_id: string;
  event_name: "ContactRegistered.v1";
  event_version: 1;
  occurred_at: string;
  correlation_id: CorrelationId;
  actor_id: string;
  aggregate_type: "contact";
  aggregate_id: string;
}>;

export type ContactRegisteredV1 = Readonly<{
  name: "ContactRegistered.v1";
  version: 1;
  payload: ContactRegisteredV1Payload;
  metadata: ContactRegisteredV1Metadata;
}>;
