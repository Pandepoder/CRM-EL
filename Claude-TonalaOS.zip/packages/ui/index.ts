export const uiPackageName = "tonala-ui";
