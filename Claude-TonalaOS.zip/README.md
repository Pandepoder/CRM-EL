# Tonala OS

Sistema operativo territorial construido como modular monolith event-driven.

## Requisitos

- Node.js 24 o compatible.
- pnpm 11.
- Docker con Docker Compose.

## Instalacion

```bash
corepack enable
pnpm install
```

Copia `.env.example` a `.env` para desarrollo local.

## Entorno Local

PostgreSQL local corre en Docker Compose. No se requiere base remota para desarrollo diario.

```bash
pnpm db:start
pnpm db:migrate
pnpm db:seed
pnpm validate
```

Comandos utiles:

```bash
pnpm db:status
pnpm db:stop
pnpm db:reset
pnpm typecheck
pnpm lint
pnpm check:boundaries
pnpm test:unit
pnpm test:integration
pnpm test
pnpm validate:unit
```

Datos temporales: volumen Docker `tonala_os_postgres_data`. `pnpm db:reset` elimina ese volumen y reconstruye migraciones/seeds.

`pnpm test:unit` y `pnpm validate:unit` no requieren PostgreSQL. `pnpm test`,
`pnpm test:integration` y `pnpm validate` requieren `.env` con `DATABASE_URL`
y un PostgreSQL disponible, normalmente iniciado con `pnpm db:start`.

## Estructura

```txt
apps/web
packages/modules/<module>/{domain,application,infrastructure,contracts}
packages/shared/{kernel,database,auth,outbox,observability,errors}
packages/ui
packages/config
db/migrations
db/seeds
docs/adr
```

## Reglas De Arquitectura

- Module-first.
- Los modulos no importan `domain`, `application` o `infrastructure` internos de otros modulos.
- La comunicacion entre modulos ocurre por contratos publicos, casos de uso autorizados, eventos o query models explicitos.
- Next.js sera delivery layer: autentica, autoriza, valida entrada, invoca casos de uso y traduce resultado.
- Supabase es infraestructura, no arquitectura.

El boundary checker actual es una primera defensa automatizada. Podra complementarse despues con herramientas de analisis de dependencias, pero desde el Bloque 1 ya falla ante imports prohibidos.

## Convencion De Ramas Y Commits

Rama principal: `main`.

Ramas de trabajo:

- `feature/<descripcion-corta>`
- `fix/<descripcion-corta>`
- `chore/<descripcion-corta>`
- `adr/<numero-tema>`

Commits:

- `feat: ...`
- `fix: ...`
- `chore: ...`
- `docs: ...`
- `test: ...`
- `refactor: ...`
- `adr: ...`
