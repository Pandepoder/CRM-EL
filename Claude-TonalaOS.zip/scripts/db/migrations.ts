import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import pg from "pg";

type Migration = {
  readonly name: string;
  readonly sql: string;
};

export async function readMigrations(migrationsDir = "db/migrations"): Promise<Migration[]> {
  const entries = await readdir(migrationsDir);
  const sqlFiles = entries.filter((entry) => entry.endsWith(".sql")).sort();

  return Promise.all(
    sqlFiles.map(async (name) => ({
      name,
      sql: await readFile(path.join(migrationsDir, name), "utf8")
    }))
  );
}

export async function applyMigrations(connectionString: string): Promise<string[]> {
  const pool = new pg.Pool({ connectionString });

  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        name text PRIMARY KEY,
        applied_at timestamptz NOT NULL DEFAULT now()
      );
    `);

    const applied: string[] = [];
    for (const migration of await readMigrations()) {
      const existing = await pool.query("SELECT 1 FROM schema_migrations WHERE name = $1", [
        migration.name
      ]);
      if (existing.rowCount && existing.rowCount > 0) {
        continue;
      }

      await pool.query("BEGIN");
      try {
        await pool.query(migration.sql);
        await pool.query("INSERT INTO schema_migrations (name) VALUES ($1)", [migration.name]);
        await pool.query("COMMIT");
        applied.push(migration.name);
      } catch (error) {
        await pool.query("ROLLBACK");
        throw error;
      }
    }

    return applied;
  } finally {
    await pool.end();
  }
}
