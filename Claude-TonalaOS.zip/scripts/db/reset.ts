import { spawn } from "node:child_process";

function run(command: string, args: readonly string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: "inherit", shell: true });
    child.on("exit", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`${command} ${args.join(" ")} failed with exit code ${code ?? "unknown"}`));
      }
    });
    child.on("error", reject);
  });
}

await run("docker", ["compose", "down", "-v"]);
await run("docker", ["compose", "up", "-d", "db"]);
await run("pnpm", ["db:wait"]);
await run("pnpm", ["db:migrate"]);
await run("pnpm", ["db:seed"]);
