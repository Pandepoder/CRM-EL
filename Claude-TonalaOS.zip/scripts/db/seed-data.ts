export const roleSeeds = [
  { key: "admin", name: "Administrador" },
  { key: "direction", name: "Direccion" },
  { key: "territorial_coordinator", name: "Coordinador territorial" },
  { key: "capturist", name: "Capturista" },
  { key: "visit_responsible", name: "Responsable de visita" }
] as const;

export const demoUserSeeds = [
  {
    email: "admin.demo@tonala-os.local",
    displayName: "Admin Demo",
    roleKey: "admin"
  },
  {
    email: "coordinador.demo@tonala-os.local",
    displayName: "Coordinador Demo",
    roleKey: "territorial_coordinator"
  }
] as const;

export const catalogSeed = {
  catalogType: "colonies",
  sourceName: "development-fixture",
  sourceVersion: "2026-07-28-block-2"
} as const;

export const colonySeeds = [
  "Colonia Desarrollo Norte",
  "Colonia Desarrollo Centro",
  "Colonia Desarrollo Sur"
] as const;
