import pg from "pg";

import { catalogSeed, colonySeeds, demoUserSeeds, roleSeeds } from "./seed-data.js";

export type SeedResult = {
  readonly roles: number;
  readonly users: number;
  readonly colonies: number;
};

type CountRow = {
  readonly count: string;
};

async function countTable(pool: pg.Pool, table: string): Promise<number> {
  const result = await pool.query<CountRow>(`SELECT COUNT(*)::text AS count FROM ${table}`);
  return Number(result.rows[0]?.count ?? 0);
}

export async function seedDatabase(connectionString: string): Promise<SeedResult> {
  const pool = new pg.Pool({ connectionString });

  try {
    await pool.query("BEGIN");

    for (const role of roleSeeds) {
      await pool.query(
        `
          INSERT INTO roles (key, name)
          VALUES ($1, $2)
          ON CONFLICT (key) DO UPDATE SET name = EXCLUDED.name
        `,
        [role.key, role.name]
      );
    }

    const catalog = await pool.query<{ id: string }>(
      `
        INSERT INTO catalog_versions (catalog_type, source_name, source_version)
        VALUES ($1, $2, $3)
        ON CONFLICT (catalog_type, source_name, source_version)
        DO UPDATE SET imported_at = catalog_versions.imported_at
        RETURNING id
      `,
      [catalogSeed.catalogType, catalogSeed.sourceName, catalogSeed.sourceVersion]
    );
    const catalogVersionId = catalog.rows[0]?.id;
    if (!catalogVersionId) {
      throw new Error("Catalog version seed did not return an id");
    }

    for (const colonyName of colonySeeds) {
      await pool.query(
        `
          INSERT INTO colonies (catalog_version_id, name)
          VALUES ($1, $2)
          ON CONFLICT (catalog_version_id, name) DO UPDATE SET status = 'active'
        `,
        [catalogVersionId, colonyName]
      );
    }

    for (const user of demoUserSeeds) {
      await pool.query(
        `
          INSERT INTO user_profiles (email, display_name, role_id)
          SELECT $1, $2, roles.id
          FROM roles
          WHERE roles.key = $3
          ON CONFLICT (email) DO UPDATE
          SET display_name = EXCLUDED.display_name,
              role_id = EXCLUDED.role_id,
              updated_at = now(),
              version = user_profiles.version + 1
        `,
        [user.email, user.displayName, user.roleKey]
      );
    }

    await pool.query("COMMIT");

    return {
      roles: await countTable(pool, "roles"),
      users: await countTable(pool, "user_profiles"),
      colonies: await countTable(pool, "colonies")
    };
  } catch (error) {
    await pool.query("ROLLBACK");
    throw error;
  } finally {
    await pool.end();
  }
}
