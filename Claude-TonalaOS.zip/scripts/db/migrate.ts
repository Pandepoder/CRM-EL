import "dotenv/config";

import { loadAppEnv } from "../../packages/config/index.js";
import { applyMigrations } from "./migrations.js";

const env = loadAppEnv();
const applied = await applyMigrations(env.private.DATABASE_URL);

if (applied.length === 0) {
  console.warn("No pending migrations.");
} else {
  console.warn(`Applied migrations: ${applied.join(", ")}`);
}
